import os
from typing import List
from langchain.chains import create_extraction_chain_pydantic
from langchain_core.pydantic_v1 import BaseModel
from langchain import hub
from dataloader import load_high
from agentic_chunker import AgenticChunker
import google.generativeai as genai

# Set up the Google Gemini API key
GEMINI_API_KEY ="AIzaSyDD4IV0vKKn1qryQbiQ76DlMDRRYYb4U1k"
genai.configure(api_key=GEMINI_API_KEY)

# Pydantic data class
class Sentences(BaseModel):
    sentences: List[str]

# Function to call the Gemini model
def call_gemini(text, system_prompt=None):
    model = genai.GenerativeModel("gemini-1.5-pro")  # Use the correct model version
    response = model.generate_content([{"role": "system", "content": system_prompt}, {"role": "user", "content": text}])
    return response.text.strip()

# Function to extract propositions
def get_propositions(text, system_prompt, extraction_chain):
    # Call Gemini API
    response_text = call_gemini(text, system_prompt)

    # Use the extraction chain to parse propositions
    propositions = extraction_chain.run(response_text)[0].sentences
    return propositions

# Main function to chunk an essay
def run_chunk(essay):
    # Pulling template from LangChain Hub
    obj = hub.pull("wfh/proposal-indexing")

    # Define the Gemini system prompt
    system_prompt = "Extract the key sentences as standalone propositions from the input text."

    # Extraction chain setup
    extraction_chain = create_extraction_chain_pydantic(pydantic_schema=Sentences, llm=None)

    paragraphs = essay.split("\n\n")
    essay_propositions = []

    for i, para in enumerate(paragraphs):
        propositions = get_propositions(para, system_prompt, extraction_chain)
        essay_propositions.extend(propositions)
        print(f"Done with paragraph {i}")

    # Chunking the extracted propositions
    ac = AgenticChunker()
    ac.add_propositions(essay_propositions)
    ac.pretty_print_chunks()
    chunks = ac.get_chunks(get_type='list_of_strings')

    return chunks
