import google.generativeai as genai
from concurrent.futures import ThreadPoolExecutor
import os

# Set up Google API Key
GEMINI_API_KEY ="AIzaSyDD4IV0vKKn1qryQbiQ76DlMDRRYYb4U1k"
genai.configure(api_key=GEMINI_API_KEY)

# System prompt with medical summarization requirements
sum_prompt = """
Generate a structured summary from the provided medical source (report, paper, or book), strictly adhering to the following categories. The summary should list key information under each category in a concise format: 'CATEGORY_NAME: Key information'. No additional explanations or detailed descriptions are necessary unless directly related to the categories:

ANATOMICAL_STRUCTURE: Mention any anatomical structures specifically discussed.
BODY_FUNCTION: List any body functions highlighted.
BODY_MEASUREMENT: Include normal measurements like blood pressure or temperature.
BM_RESULT: Results of these measurements.
BM_UNIT: Units for each measurement.
BM_VALUE: Values of these measurements.
LABORATORY_DATA: Outline any laboratory tests mentioned.
LAB_RESULT: Outcomes of these tests (e.g., 'increased', 'decreased').
LAB_VALUE: Specific values from the tests.
LAB_UNIT: Units of measurement for these values.
MEDICINE: Name medications discussed.
MED_DOSE, MED_DURATION, MED_FORM, MED_FREQUENCY, MED_ROUTE, MED_STATUS, MED_STRENGTH, MED_UNIT, MED_TOTALDOSE: Provide concise details for each medication attribute.
PROBLEM: Identify any medical conditions or findings.
PROCEDURE: Describe any procedures.
PROCEDURE_RESULT: Outcomes of these procedures.
PROC_METHOD: Methods used.
SEVERITY: Severity of the conditions mentioned.
MEDICAL_DEVICE: List any medical devices used.
SUBSTANCE_ABUSE: Note any substance abuse mentioned.
Each category should be addressed only if relevant to the content of the medical source. Ensure the summary is clear and direct, suitable for quick reference.
"""

# Function to call Google Gemini API
def call_gemini_api(chunk):
    model = genai.GenerativeModel("gemini-1.5-pro")  # Use the correct model version
    response = model.generate_content([
        {"role": "system", "content": sum_prompt},
        {"role": "user", "content": chunk}
    ])
    return response.text.strip()

# Function to split text into chunks
def split_into_chunks(text, chunk_size=1500):
    words = text.split()
    chunks = []
    for i in range(0, len(words), chunk_size):
        chunk = ' '.join(words[i:i + chunk_size])
        chunks.append(chunk)
    return chunks

# Function to process chunks using ThreadPoolExecutor
def process_chunks(content):
    chunks = split_into_chunks(content)

    # Process chunks in parallel
    with ThreadPoolExecutor() as executor:
        responses = list(executor.map(call_gemini_api, chunks))
    
    return responses

if __name__ == "__main__":
    content = """Insert your medical text or document content here to test the functionality."""
    
    # Call processing function
    results = process_chunks(content)
    
    # Print the summaries for each chunk
    for i, result in enumerate(results):
        print(f"Chunk {i+1} Summary:\n{result}\n")
