import numpy as np
import google.generativeai as genai

from ._utils import compute_args_hash, wrap_embedding_func_with_attrs
from .base import BaseKVStorage

# Configure Gemini API key
import os
from dotenv import load_dotenv

GEMINI_API_KEY ="AIzaSyDD4IV0vKKn1qryQbiQ76DlMDRRYYb4U1k"
genai.configure(api_key=GEMINI_API_KEY)


async def gemini_complete_if_cache(
    model: str, prompt: str, system_prompt: str = None, history_messages: list = [], **kwargs
) -> str:
    """
    Use Gemini API to complete a prompt, optionally using a cache.
    """
    hashing_kv: BaseKVStorage = kwargs.pop("hashing_kv", None)
    messages = []

    # Format the prompt according to Gemini's expected input
    if system_prompt:
        messages.append({"role": "system", "parts": [system_prompt]})
    for msg in history_messages:
        messages.append({"role": msg["role"], "parts": [msg["content"]]})
    messages.append({"role": "user", "parts": [prompt]})

    if hashing_kv is not None:
        # Check if cached result exists
        args_hash = compute_args_hash(model, messages)
        if_cache_return = await hashing_kv.get_by_id(args_hash)
        if if_cache_return is not None:
            return if_cache_return["return"]

    # Generate response using Gemini
    gemini_client = genai.GenerativeModel(model)
    response = await gemini_client.generate_content_async(messages, **kwargs)

    # Extract response content
    response_text = response.text.strip()

    # Update cache if applicable
    if hashing_kv is not None:
        await hashing_kv.upsert(
            {args_hash: {"return": response_text, "model": model}}
        )
    return response_text


async def gemini_1_5_pro_complete(
    prompt: str, system_prompt: str = None, history_messages: list = [], **kwargs
) -> str:
    """
    Complete a prompt using Gemini 1.5 Pro.
    """
    return await gemini_complete_if_cache(
        "gemini-1.5-pro",
        prompt,
        system_prompt=system_prompt,
        history_messages=history_messages,
        **kwargs,
    )


async def gemini_1_5_pro_mini_complete(
    prompt: str, system_prompt: str = None, history_messages: list = [], **kwargs
) -> str:
    """
    Complete a prompt using a smaller Gemini 1.5 Pro version (if available).
    """
    return await gemini_complete_if_cache(
        "gemini-1.5-pro-mini",
        prompt,
        system_prompt=system_prompt,
        history_messages=history_messages,
        **kwargs,
    )


@wrap_embedding_func_with_attrs(embedding_dim=1536, max_token_size=8192)
async def gemini_embedding(texts: list[str]) -> np.ndarray:
    """
    Generate embeddings for a list of texts using Gemini API.
    """
    model = genai.GenerativeModel("embedding-001")
    response = await model.embed_content_async(
        content=texts, task_type="retrieval_document"
    )

    # Return embeddings as a numpy array
    return np.array(response.embeddings)
