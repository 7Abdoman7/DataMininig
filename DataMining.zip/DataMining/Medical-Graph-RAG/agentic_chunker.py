import google.generativeai as genai
import uuid
import os
from typing import Optional

GEMINI_API_KEY ="AIzaSyDD4IV0vKKn1qryQbiQ76DlMDRRYYb4U1k"

class AgenticChunker:
    def __init__(self, gemini_api_key=GEMINI_API_KEY):
        self.chunks = {}
        self.id_truncate_limit = 5

        # Whether or not to update/refine summaries and titles as you get new information
        self.generate_new_metadata_ind = True
        self.print_logging = True

        # Configure Gemini API client
        genai.configure(api_key=GEMINI_API_KEY)
        self.model = genai.GenerativeModel('gemini-1.5-pro')

    def _invoke_gemini(self, prompt):
        """
        Generic function to send a prompt to Gemini API and get a response.
        """
        response = self.model.generate_content(prompt)
        return response.text.strip()

    def add_propositions(self, propositions):
        for proposition in propositions:
            self.add_proposition(proposition)

    def add_proposition(self, proposition):
        if self.print_logging:
            print(f"\nAdding: '{proposition}'")

        # If it's your first chunk, create a new one
        if len(self.chunks) == 0:
            if self.print_logging:
                print("No chunks, creating a new one")
            self._create_new_chunk(proposition)
            return

        chunk_id = self._find_relevant_chunk(proposition)

        # If a relevant chunk is found
        if chunk_id:
            if self.print_logging:
                print(f"Chunk Found ({self.chunks[chunk_id]['chunk_id']}), adding to: {self.chunks[chunk_id]['title']}")
            self.add_proposition_to_chunk(chunk_id, proposition)
            return
        else:
            if self.print_logging:
                print("No chunks found")
            self._create_new_chunk(proposition)

    def add_proposition_to_chunk(self, chunk_id, proposition):
        self.chunks[chunk_id]['propositions'].append(proposition)

        if self.generate_new_metadata_ind:
            self.chunks[chunk_id]['summary'] = self._update_chunk_summary(self.chunks[chunk_id])
            self.chunks[chunk_id]['title'] = self._update_chunk_title(self.chunks[chunk_id])

    def _update_chunk_summary(self, chunk):
        prompt = f"""
        You are managing a group of sentences that share a similar topic. A new proposition was added.
        Generate a very brief 1-sentence updated summary of the chunk.

        Propositions in the chunk:
        {chr(10).join(chunk['propositions'])}

        Current summary: {chunk['summary']}

        Output only the updated summary.
        """
        return self._invoke_gemini(prompt)

    def _update_chunk_title(self, chunk):
        prompt = f"""
        Generate a short, generalizable title for the following chunk based on its propositions and summary.

        Propositions:
        {chr(10).join(chunk['propositions'])}

        Summary: {chunk['summary']}
        Title: {chunk['title']}

        Output only the updated title.
        """
        return self._invoke_gemini(prompt)

    def _get_new_chunk_summary(self, proposition):
        prompt = f"""
        Generate a concise 1-sentence summary for a new chunk containing the following proposition:
        "{proposition}"

        Output only the summary.
        """
        return self._invoke_gemini(prompt)

    def _get_new_chunk_title(self, summary):
        prompt = f"""
        Generate a brief title for the following summary:
        "{summary}"

        Output only the title.
        """
        return self._invoke_gemini(prompt)

    def _create_new_chunk(self, proposition):
        new_chunk_id = str(uuid.uuid4())[:self.id_truncate_limit]
        new_chunk_summary = self._get_new_chunk_summary(proposition)
        new_chunk_title = self._get_new_chunk_title(new_chunk_summary)

        self.chunks[new_chunk_id] = {
            'chunk_id': new_chunk_id,
            'propositions': [proposition],
            'title': new_chunk_title,
            'summary': new_chunk_summary,
            'chunk_index': len(self.chunks)
        }
        if self.print_logging:
            print(f"Created new chunk ({new_chunk_id}): {new_chunk_title}")

    def get_chunk_outline(self):
        outline = ""
        for chunk_id, chunk in self.chunks.items():
            outline += f"Chunk ID: {chunk['chunk_id']}\nChunk Name: {chunk['title']}\nChunk Summary: {chunk['summary']}\n\n"
        return outline

    def _find_relevant_chunk(self, proposition):
        current_chunk_outline = self.get_chunk_outline()

        prompt = f"""
        Determine if the following proposition belongs to any of the existing chunks.

        Proposition:
        "{proposition}"

        Current Chunks:
        {current_chunk_outline}

        If the proposition fits into an existing chunk, output the Chunk ID.
        If no chunk matches, output "No chunks".
        """
        response = self._invoke_gemini(prompt)
        return response if len(response) == self.id_truncate_limit else None

    def get_chunks(self, get_type='dict'):
        if get_type == 'dict':
            return self.chunks
        if get_type == 'list_of_strings':
            return [" ".join(chunk['propositions']) for chunk in self.chunks.values()]

    def pretty_print_chunks(self):
        print(f"\nYou have {len(self.chunks)} chunks\n")
        for chunk_id, chunk in self.chunks.items():
            print(f"Chunk #{chunk['chunk_index']}")
            print(f"Chunk ID: {chunk_id}")
            print(f"Summary: {chunk['summary']}")
            print("Propositions:")
            for prop in chunk['propositions']:
                print(f"    - {prop}")
            print("\n")

    def pretty_print_chunk_outline(self):
        print("Chunk Outline\n")
        print(self.get_chunk_outline())

if __name__ == "__main__":
    ac = AgenticChunker()

    propositions = [
        'The month is October.',
        'The year is 2023.',
        "One of the most important things I didn't understand as a child was how superlinear performance works.",
        'Teachers told us that the returns were linear.',
        "I heard a thousand times that 'You get out what you put in.'",
    ]

    ac.add_propositions(propositions)
    ac.pretty_print_chunks()
    ac.pretty_print_chunk_outline()
    print(ac.get_chunks(get_type='list_of_strings'))
