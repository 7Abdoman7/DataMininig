import os
import uuid
import numpy as np
from neo4j import GraphDatabase
import google.generativeai as genai  # Gemini API library
from camel.storages import Neo4jGraph
from summerize import process_chunks  # Assuming this still applies

# Configure the Gemini API Key
GEMINI_API_KEY ="AIzaSyDD4IV0vKKn1qryQbiQ76DlMDRRYYb4U1k"
genai.configure(api_key=GEMINI_API_KEY)

# System Prompts
sys_prompt_one = """
Please answer the question using insights supported by provided graph-based data relevant to medical information.
"""

sys_prompt_two = """
Modify the response to the question using the provided references. Include precise citations relevant to your answer. 
Include citations in the format [1][3]. If references are irrelevant, provide a concise answer.
"""

def get_embedding(text, model_name="embedding-001"):
    """
    Generate text embeddings using Gemini API.
    Note: Gemini currently does not have a dedicated text embedding endpoint. Placeholder here assumes functionality.
    """
    # For future updates when embeddings are released, placeholder method
    embedding_vector = np.random.rand(768).tolist()  # Replace with real call if Gemini supports embeddings
    return embedding_vector

def call_llm(sys_prompt, user_input):
    """
    Call Gemini API to generate chat-based responses.
    """
    model = genai.GenerativeModel("gemini-1.5-pro")
    response = model.generate_content([
        {"role": "system", "parts": [sys_prompt]},
        {"role": "user", "parts": [user_input]},
    ])
    return response.text

def fetch_texts(n4j):
    query = "MATCH (n) RETURN n.id AS id"
    return n4j.query(query)

def add_embeddings(n4j, node_id, embedding):
    query = "MATCH (n) WHERE n.id = $node_id SET n.embedding = $embedding"
    n4j.query(query, params={"node_id": node_id, "embedding": embedding})

def add_nodes_emb(n4j):
    nodes = fetch_texts(n4j)
    for node in nodes:
        if node['id']:
            embedding = get_embedding(node['id'])
            add_embeddings(n4j, node['id'], embedding)

def add_ge_emb(graph_element):
    for node in graph_element.nodes:
        emb = get_embedding(node.id)
        node.properties['embedding'] = emb
    return graph_element

def add_sum(n4j, content, gid):
    summary = process_chunks(content)
    create_sum_query = """
        CREATE (s:Summary {content: $sum, gid: $gid})
        RETURN s
        """
    s = n4j.query(create_sum_query, {'sum': summary, 'gid': gid})

    link_sum_query = """
        MATCH (s:Summary {gid: $gid}), (n)
        WHERE n.gid = s.gid AND NOT n:Summary
        CREATE (s)-[:SUMMARIZES]->(n)
        RETURN s, n
        """
    n4j.query(link_sum_query, {'gid': gid})
    return s

def get_response(n4j, gid, query):
    self_cont = ret_context(n4j, gid)
    link_cont = link_context(n4j, gid)
    
    user_one = f"The question is: {query}\nThe provided information is: {''.join(self_cont)}"
    res = call_llm(sys_prompt_one, user_one)
    
    user_two = f"The question is: {query}\nThe last response is: {res}\nThe references are: {''.join(link_cont)}"
    final_res = call_llm(sys_prompt_two, user_two)
    
    return final_res

def ret_context(n4j, gid):
    cont = []
    ret_query = """
        MATCH (n)
        WHERE n.gid = $gid AND NOT n:Summary
        WITH collect(n) AS nodes
        UNWIND nodes AS n
        UNWIND nodes AS m
        MATCH (n)-[r]-(m)
        WHERE id(n) < id(m)
        RETURN n.id AS NodeId1, TYPE(r) AS relType, m.id AS NodeId2
    """
    res = n4j.query(ret_query, {'gid': gid})
    for r in res:
        cont.append(r['NodeId1'] + r['relType'] + r['NodeId2'])
    return cont

def link_context(n4j, gid):
    cont = []
    retrieve_query = """
        MATCH (n)-[r:REFERENCE]->(m)
        WHERE n.gid = $gid
        RETURN n.id AS NodeId1, TYPE(r) AS ReferenceType, m.id AS Mid
    """
    res = n4j.query(retrieve_query, {'gid': gid})
    for r in res:
        cont.append(f"Reference: {r['NodeId1']} has a reference {r['ReferenceType']} -> {r['Mid']}")
    return cont

def str_uuid():
    return str(uuid.uuid4())